==========================
Format Specification Suite
==========================
:uri: cz-ndic_d2-predefined-location-set-v1.1
:format: DATEX II Predefined Location Publication - Predefined Location Set

This repository provides tools and files for given format:

- schema
- sample(s)
- documentation
- test suite
- unified `tox` based interface for related tools

About described format
======================

For all details, see `FORMAT.yaml`.

Using provided tools
====================

For all details, see `tox.rst`.

