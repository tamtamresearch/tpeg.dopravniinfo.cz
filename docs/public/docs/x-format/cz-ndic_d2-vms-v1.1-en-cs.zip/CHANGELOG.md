# Changelog

## Version 1.1.1

**Schema**
- No changes.

**Samples**
- Added 3 samples for VMS displaying a speed of 150 km/h.

**Documentation**
- Removed the note about pull/push as redundant.
- Added an example for VMS with a speed of 150 km/h.
- Minor textual corrections: elements in Chapter 4 are now presented as headings, cross-references to elements have been added, and grey shading was introduced in Chapter 4 to highlight examples.

## Version 1.1.0

**Schema**
- Added `feedDescription` tag for source identification.

**Samples**
- Corrected samples with `feedDescription` tag.

**Documentation**
- Added `feedDescription` description into documentation.

## Version 1.0

- Initial format and documentation.
