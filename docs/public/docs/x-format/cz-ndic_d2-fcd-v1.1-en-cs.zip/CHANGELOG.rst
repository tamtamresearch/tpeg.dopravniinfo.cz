Changelog
=========

version 1.1.0 

- format updated to allow for vehicle type partial feed (i.e. for lorries and vehicles)

version 1.0.0 

- Initial format and documentation