==========================
Format Specification Suite
==========================
:uri: cz-ndic_lod-srti-sparql-v1.0
:format: RDF - Dopravní informace souvisící s bezpečností silničního provozu

This repository provides tools and files for given format:

- schema
- sample(s)
- documentation
- test suite
- unified `tox` based interface for related tools

About described format
======================

For all details, see `FORMAT.yaml`.

Using provided tools
====================

For all details, see `tox.rst`.

Changelog
=========

version 1.0.0 

- Innitial format and documentation



