Changelog
=========

version 1.1.0 

- added feedDescription linking to a file source

version 1.0.0 

- Initial format and documentation