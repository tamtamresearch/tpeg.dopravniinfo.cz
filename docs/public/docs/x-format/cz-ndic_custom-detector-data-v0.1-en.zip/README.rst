==========================
Format Specification Suite
==========================
:uri: cz-ndic_custom-detector-data-v0.1
:format: Custom XML - Measured data - Traffic detector data

This repository provides tools and files for given format:

- schema
- sample(s)
- documentation
- test suite
- unified `tox` based interface for related tools

About described format
======================

For all details, see `FORMAT.yaml`.

Using provided tools
====================

For all details, see `tox.rst`.
