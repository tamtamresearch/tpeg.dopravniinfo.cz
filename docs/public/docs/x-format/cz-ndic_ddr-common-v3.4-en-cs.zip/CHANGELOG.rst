Changelog
=========

version 3.4.0 

- Koncepční změny:

	- Konec "DDR ve Wordu", nahrazen formáty "ddr-common" a "ddr-winter"
	- Jeden pevný formát, žádná formátová variabilita
	- Formát definován schématem
	- Snaha o zpětnou kompatibilitu
	
		- zachovat stávající názvy elementů a atributů, a to i v případě, že působí "nehezky" (ale už se užívají)
		- nové elementy přidávat na konce svých kontejnerů, ať nejsou zaskočeni ty parsery dat, které očekávají nějaké dnes užívané pořadí elementů
		- vyřazování dnes užívaných atributů provedeme jen tam, kde je významně pravděpodobné, že se nenačítají.

	- Zjednodušení
	- Použité metody popisu polohy
	- Sjednocení popisu trasy objížďky s polohou události
	
- Dílčí změny:

	- DOC/@version nahrazeno jmenným prostorem (namespace)
	- **Vyřazení** řady nadbytečných atributů

		- Zjednodušení obálky nebo obecné případy vyřazením:

			- //\*/@Language
			- //DOC/INF atributy sender, receiver a transmission
			- /DOC/@dataset
			- /DOC/MJD/@count

		- Zjednodušení časové platnosti vyřazením:

			- //TMCE/@duration
			- //TMCE/@durationtext
			- //MSG/MTIME/TUPD
			- //MSG/MTIME/@format

		- Zjednodušení popisu polohy

			- //MLOC/TXPLA

		- Upřesnění směrovosti stávajícím tagem @directionalityvalue:

			- "-1": (přidáno) ovlivněn protisměrný provoz
			- "1": (stávající) ovlivněn výchozí směr provozu
			- "2": (stávající) ovlivněny oba směry provozu

		- Zjednodušení Informace o životním cyklu a důvěryhodnosti zprávy vyřazením:

			- //MSG/@Progress  
			- //MSG/@confirmed  
			- //MSG/@lifecycle
			- //MSG/@planned  
			- //MSG/@valid
			- //TMCE/@credibility

		- Jiné atributy zprávy:

			- //TMCE/@urgency (Hodnota urgency je zbytná, protože se váže na postup práce operátora a nikoliv k samotné urgency. Zcela postačí atribut urgencyvalue)

	- Přidána informace o poskytovateli
	- Souřadnice počátku, ale i konce události. Elementy COORD a COORDEND popisují souřadnice počátku a konce události
	- "WGS-84" a "S-JTSK"
	- Přidán popis polohy pomocí OpenLR
	- Identifikátor /DOC/@id má přesný formát
	- Identifikátor //MSG/@id max. 38 znaků

více viz https://gitlab.com/nominated-body-cz/providers/cz-ndic/formats/cz-ndic_ddr-common-v3.4/-/issues

version 3.2.5.0 

- Původní dokumentace a schéma