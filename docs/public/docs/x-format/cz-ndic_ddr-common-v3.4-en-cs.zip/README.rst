==========================
Format Specification Suite
==========================

:format: DDR Common v3.4
:uri: cz-ndic_ddr-common-v3.4

This repository provides tools and files for given format:

- schema
- sample(s)
- documentation
- test suite
- unified `tox` based interface for related tools

About described format
======================

For all details, see `FORMAT.yaml`.

Using provided tools
====================

For all details, see `tox.rst`.