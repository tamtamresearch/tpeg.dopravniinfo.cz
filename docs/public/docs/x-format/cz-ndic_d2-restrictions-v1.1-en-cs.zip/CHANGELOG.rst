Changelog
=========

version 1.1.0rc

- added feed type to schema and samples
- added OpenLR location to schema

version 1.0.1

- revision of the documentation, proofreading, changes to examples

version 1.0.0 

- Initial format and documentation