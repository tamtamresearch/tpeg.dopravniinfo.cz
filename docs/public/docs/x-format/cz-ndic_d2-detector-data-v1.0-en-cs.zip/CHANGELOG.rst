Changelog
=========

version 1.0.1 

- Textual revision of the documentation

version 1.0.0 

- Initial format and documentation