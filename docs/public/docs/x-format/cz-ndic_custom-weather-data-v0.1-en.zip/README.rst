==========================
Format Specification Suite
==========================
:uri: cz-ndic_custom-weather-data-v0.1
:format: NDIC Custom XML - Measured data - Weather station data

This repository provides tools and files for given format:

- schema
- sample(s)
- documentation
- test suite
- unified `tox` based interface for related tools

About described format
======================

For all details, see `FORMAT.yaml`.

Using provided tools
====================

For all details, see `tox.rst`.
