Changelog
=========

version 1.0.1

- added additional physicalSupportEnum values for e.g. bridge mounted VMSs

version 1.0.0 

- Initial format and documentation