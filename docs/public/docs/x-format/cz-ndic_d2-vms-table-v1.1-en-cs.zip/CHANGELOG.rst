Changelog
=========

version 1.1

- added additional physicalSupportEnum values for e.g. bridge mounted VMSs
- corrected samples feedType, added feedDescription and headers
- samples and documentation proofread for percentage value as 0 - 100 (where 100 = 100 %).

version 1.0.0 

- Initial format and documentation