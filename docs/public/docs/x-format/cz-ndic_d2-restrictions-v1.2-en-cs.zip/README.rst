==========================
Format Specification Suite
==========================
:uri: cz-ndic_d2-restrictions-v1.2
:format: DATEX II Situation Publication - Restrictions

This repository provides tools and files for given format:

- schema
- sample(s)
- documentation
- test suite
- unified `tox` based interface for related tools

About described format
======================

For all details, see `FORMAT.yaml`.

Using provided tools
====================

For all details, see `tox.rst`.

Changelog
=========

version 1.0.0 

- Initial format and documentation

version 1.0.1

- revision of the documentation, proofreading, changes to examples

version 1.1.0rc

- added feed type to schema and samples
- added OpenLR location to schema

version 1.2

- added urlLink to situationRecord for additional description on the web
- added: feedDescription and safetyRelatedMessage tags
- corrected location of globalNtworkLinear and globalNetworkPoint in the XML tree (as extension)
- corrected type of the networkVersion to the simple string from multilingual string