==========================
Format Specification Suite
==========================
:uri: cz-ndic_d2-travel-time-v1.1
:format: DATEX II Elaborated Data Publication - Travel Time

This repository provides tools and files for given format:

- schema
- sample(s)
- documentation
- test suite
- unified `tox` based interface for related tools

About described format
======================

For all details, see `FORMAT.yaml`.

Using provided tools
====================

For all details, see `tox.rst`.

